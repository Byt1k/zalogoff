<!doctype html>
<html lang="ru">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Sravni Lombard — Агрегатор ломбардов</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css"> 
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400&display=swap" rel="stylesheet">

  <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="owlcarousel/owl.carousel.min.css">
	<link rel="stylesheet" href="owlcarousel/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/main.css">
  <script src="js/jquery-2.2.4.min.js" type="text/javascript"></script>
</head>
<body>
<header class="header">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-2">
        <a href="#"><img src="img/logo.png" alt="Sravni Lombard" class="logo"></a>
      </div>
      <div class="col-lg-7 offset-lg-1">
        <ul class="header__menu d-flex">
          <li><a href="#history" class="go">История</a></li>
          <li><a href="#warranty" class="go">Гарантии</a></li>
          <li><a href="#rating" class="go">Рейтинг ломбардов</a></li>
          <li><a href="#mass-media" class="go">СМИ о нас</a></li>
          <li><a href="#reviews" class="go">Отзывы клиентов</a></li>
        </ul>
      </div>
      <div class="col-lg-2">
        <a href="tel:+8 (800) 333-89-04" class="header__tel">+8 (800) 333-89-04</a>
      </div>
    </div>
  </div>
</header>
<div class="mobile-menu">
  <div class="container d-flex align-items-center justify-content-between">
    <a href="#"><img src="img/logo.png" alt="Sravni Lombard"></a>
    <a href="#" class="mobile_menu"><img src="img/open-menu.svg" alt="menu"></a>
  </div>
  <div class="mobile_menu_container">
    <div class="mobile_menu_content">
      <ul>
        <li><a href="#history" class="go">История</a></li>
        <li><a href="#warranty" class="go">Гарантии</a></li>
        <li><a href="#rating" class="go">Рейтинг ломбардов</a></li>
        <li><a href="#mass-media" class="go">СМИ о нас</a></li>
        <li><a href="#reviews" class="go">Отзывы клиентов</a></li>
        <li><a href="tel:+8 (800) 333-89-04">+8 (800) 333-89-04</a></li>
      </ul>
    </div>
  </div>
  <div class="mobile_menu_overlay"></div>
</div>

<section class="main">
  <!-- <img src="img/bg1.jpg" alt="bg1" class="main__bg"> -->
  
  <div class="container">
    <div class="main__slider">
    <div class="owl-carousel owl-theme main__owl-carousel">
      <div class="item">
        <div class="main__owl-carousel_title d-flex justify-content-center mb-2">
          <h3>Мы</h3>
          <span>VS</span>
          <h3>Обычный ломбард</h3>
        </div>
        <div class="main__owl-carousel_advantage d-flex align-items-center mt-4">
          <i class="fas fa-star mr-3"></i>
          <p>Ищем лучшее предложение</p>
        </div>
        <div class="main__owl-carousel_advantage d-flex align-items-center mt-4">
          <i class="fas fa-star mr-3"></i>
          <p>Больше сумма кредита</p>
        </div>
        <div class="main__owl-carousel_advantage d-flex align-items-center mt-4">
          <i class="fas fa-star mr-3"></i>
          <p>Ниже процентная ставка</p>
        </div>
      </div>
      <div class="item">
        <div class="main__owl-carousel_title d-flex justify-content-center mb-2">
          <h3>Мы</h3>
          <span>VS</span>
          <h3>МФО</h3>
        </div>
        <div class="main__owl-carousel_advantage d-flex align-items-center mt-4">
          <i class="fas fa-star mr-3"></i>
          <p>Низкий процент</p>
        </div>
        <div class="main__owl-carousel_advantage d-flex align-items-center mt-4">
          <i class="fas fa-star mr-3"></i>
          <p>Никаких штрафов</p>
        </div>
        <div class="main__owl-carousel_advantage d-flex align-items-center mt-4">
          <i class="fas fa-star mr-3"></i>
          <p>Никаких коллекторов</p>
        </div>
      </div>
      <div class="item">
        <div class="main__owl-carousel_title d-flex justify-content-center mb-2">
          <h3>Мы</h3>
          <span>VS</span>
          <h3>Банк</h3>
        </div>
        <div class="main__owl-carousel_advantage d-flex align-items-center mt-4">
          <i class="fas fa-star mr-3"></i>
          <p>Гораздо быстрее, чем в банке</p>
        </div>
        <div class="main__owl-carousel_advantage d-flex align-items-center mt-4">
          <i class="fas fa-star mr-3"></i>
          <p>Никаких подтверждений доходов</p>
        </div>
        <div class="main__owl-carousel_advantage d-flex align-items-center mt-4">
          <i class="fas fa-star mr-3"></i>
          <p>Неважно какая кредитная история</p>
        </div>
      </div>
      <div class="item">
        <div class="main__owl-carousel_title d-flex justify-content-center mb-2">
          <h3>Мы</h3>
          <span>VS</span>
          <h3>Кредитная карта</h3>
        </div>
        <div class="main__owl-carousel_advantage d-flex align-items-center mt-4">
          <i class="fas fa-star mr-3"></i>
          <p>Проценты сопоставимы</p>
        </div>
        <div class="main__owl-carousel_advantage d-flex align-items-center mt-4">
          <i class="fas fa-star mr-3"></i>
          <p>Контроль над расходами. Карта — это кабала</p>
        </div>
        <div class="main__owl-carousel_advantage d-flex align-items-center mt-4">
          <i class="fas fa-star mr-3"></i>
          <p>Никаких коллекторов и штрафов</p>
        </div>
      </div>
    </div>
  </div>
    <div class="row">
      <div class="col-lg-12">
        <h1>Есть временные сложности <br>с деньгами ?</h1>
        <p class="mt-4">Всё наладится, а пока получи сегодня <br> до 30 тыс. рублей в проверенных ломбардах</p>
        <a href="#request" class="go main-btn main__btn">Оставить заявку</a>
        <span>* Вы оставляете заявку на надёжный ломбард</span>
      </div>
    </div>
    <a href="#history" class="go main__scroll d-flex align-items-center justify-content-center">
      <img src="img/point.png" alt="arrow">
      <p>scroll</p>
    </a>
  </div>
</section>
<section class="history" id="history">
  <div class="container">
    <div class="row">
      <div class="col-12 text-center">
        <h2>Ломбарды сотни лет приходили на помощь</h2>
        <h4 class="mt-2">В ломбарды обращались короли, философы и первооткрыватели</h4>
      </div>
    </div>
    <div class="row mt-5 pt-3">
      <div class="col-lg-3 col-md-6">
        <div class="history__block text-center">
          <img src="img/1.jpg" alt="Изабелла I">
          <p>Королева Кастилии <b>Изабелла I</b> обращалась в ломбарды, чтобы финансировать путешествие Христофора Колумба</p>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="history__block text-center">
          <img src="img/2.jpg" alt="Изабелла I">
          <p>Король Пруссии <b>Фридрих II</b> пользовался ломбардами, чтобы финансировать армию</p>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="history__block text-center">
          <img src="img/3.jpg" alt="Изабелла I">
          <p>Наставник великого Платона — философ <b>Сократ</b> открыл и<br>с успехом развивал ломбард</p>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="history__block text-center">
          <img src="img/4.jpg" alt="Изабелла I">
          <p>Французкий монах <b>Бернардин Фельдторский</b> создавал пункты помощи (прообразы ломбардов) в итальянских провинциях</p>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="advice">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <form action="email.php" method="post" class="advice__block d-flex align-items-center justify-content-center">
          <h3>Получи на почту советы, о том как найти надёжный ломбард</h3>
          <div class="advice__input">
            <input type="email" name="advice-email" placeholder="Ваш email" required>
            <button type="submit">
              <img src="img/point-to.png" alt="arrow">
            </button>
            <div class="advice__input_underline"></div>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
<section class="warranty" id="warranty">
  <div class="container">
    <div class="row">
      <div class="col-12 text-center">
        <h2>Что мы вам можем гарантировать</h2>
      </div>
    </div>
    <div class="row mt-5 pt-3">
      <div class="col-12">
        <div class="d-flex justify-content-between">
          <div class="warranty__item text-center">
            <img src="img/tr.png" alt="tr" class="warranty__tr">
            <img src="img/i1.png" class="mt-5" alt="percent">
            <h3 class="mt-4 mb-3">Низкий процент</h3>
            <p>Процент как у кредитных карт многих банков. Ставка меньше <br>в 2-3 раза, чем в МФО</p>
          </div>
          <div class="warranty__item text-center">
            <img src="img/tr.png" alt="tr" class="warranty__tr">
            <img src="img/i2.png" class="mt-5" alt="percent">
            <h3 class="mt-4 mb-3">Деньги в тот же день</h3>
            <p>Работая с нами, в ломбарде можно получить деньги <br>за 30 минут</p>
          </div>
          <div class="warranty__item text-center">
            <img src="img/tr.png" alt="tr" class="warranty__tr">
            <img src="img/i3.png" class="mt-5" alt="percent">
            <h3 class="mt-4 mb-3">Спокойствие</h3>
            <p>Никаких коллекторов, штрафов <br>и пени. Если не погасить кредит, залог остаётся в ломбарде</p>
          </div>
          <div class="warranty__item text-center">
            <img src="img/tr.png" alt="tr" class="warranty__tr">
            <img src="img/i4.png" class="mt-5" alt="percent">
            <h3 class="mt-4 mb-3">Надёжность</h3>
            <p>У нас только надёжные сетевые ломбарды, имеющие множество отзывов клиентов</p>
          </div>
          <div class="warranty__item text-center">
            <img src="img/tr.png" alt="tr" class="warranty__tr">
            <img src="img/i5.png" class="mt-5" alt="percent">
            <h3 class="mt-4 mb-3">Бесплатно</h3>
            <p>Мы получаем комиссию от ломбардов, если вы оформите заявку на нашем сайте.</p>
          </div>
        </div>
      </div>
    </div>
    <div class="row mt-4">
      <div class="col-12 d-flex justify-content-center">
        <div class="warranty__block d-flex mt-4">
          <span>1.</span>
          <p><b>Работайте</b> только с надёжными<br>ломбарадами</p>
        </div>
        <div class="warranty__block d-flex mt-4">
          <span>2.</span>
          <p><b>Решите</b> свои временые трудности<br>с максимальной выгодой</p>
        </div>
        <div class="warranty__block d-flex mt-4">
          <span>3.</span>
          <p><b>Получите</b> максимальную суму кредита<br>за ваш залог по минимальной ставке</p>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="rating" id="rating">
  <div class="container">
    <div class="row">
      <div class="col-12 text-center">
        <h2>Рейтинг ломбардов</h2>
      </div>
    </div>
    <div class="row mt-5 pt-3 mb-4">
      <div class="col-md-1 text-center">
        <p class="gray dn">Ломбард</p>
      </div>
      <div class="col-md-2 text-center">
        <p class="gray dn">Сайт</p>
      </div>
      <div class="col-md-3 text-center">
        <p class="gray dn">Виды залога</p>
      </div>
      <div class="col-md-2 text-center">
        <p class="gray dn">Сетевой ломбард</p>
      </div>
      <div class="col-md-2 text-center">
        <p class="gray dn">Рейтинг</p>
      </div>
    </div>
    
    <div class="accordion" id="accordionExample">

      <div class="card">
        <div class="card-header" id="headingOne">
          <div class="row align-items-center">
            <div class="col-md-1 text-center">
              <img src="img/golfstream.jpg" alt="Гольфстрим" class="w-100">
            </div>
            <div class="col-md-2 text-center">
              <a href="https://golfstreamcredit.ru"  target="_blank" class="rating__site"><span class="rating__add gray">Сайт:&nbsp;</span>golfstreamcredit.ru</a>
            </div>
            <div class="col-md-3 text-center">
              <p class="px-1"><span class="rating__add gray">Виды залога:&nbsp;</span>Автомобили, ювелирные украшения, спецтехника</p>
            </div>
            <div class="col-md-2 text-center">
              <p class="rating__network"><span class="rating__add gray">Сетевой ломбард:&nbsp;</span>Нет</p>
            </div>
            <div class="col-md-2 text-center ">
              <b>4,8 из 5</b><br>
              <p class="gray rating__count-reviews">(9 отзывов)</p>
              <button class="btn btn-link rating__btn-reviews" type="button" data-toggle="collapse" data-target="#collapse1" aria-expanded="false" aria-controls="collapseOne">Читать отзывы</button>
            </div>
            <div class="col-md-2">
              <a href="golfstream.html" class="second-btn rating__btn">Подробнее</a>
            </div>
          </div>
          <div id="collapse1" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
            <div class="card-body">
              <div class="col-12">
                <div class="owl-carousel owl-theme rating__reviews_owl-carousel">
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Валерий Богданов</h3>
                      <p class="gray fz14">17 марта 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Предоставили займ под залог авто быстро, без проблем. Документов запросили по минимуму. Процент реально небольшой назначили, минимум 4, а это немного. Я в принципе ни у кого таких предложений больше не видел. Обращаться можно.</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Игорь Решетов</h3>
                      <p class="gray fz14">17 марта 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Приличная компания с приятным офисом и сотрудниками. Брал займ под залог ПТС, процентная ставка ниже, чем у большинства подобных компаний. Всё официально, но документов требуется по минимуму. Никаких проблем с досрочным погашением у меня не возникло. Можно обращаться.</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Никита Кашкевич</h3>
                      <p class="gray fz14">17 февраля 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Закладывал машину, выкупил вовремя, так что могу лишь поблагодарить. Выручили меня в трудной ситуации. В банках кредит не давали, т.к. плохая история. Здесь же на это не стали смотреть. Никаких поручителей и справок не потребовалось. За процент жаба душит, конечно, но в других фирмах ещё дороже.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header" id="headingOne">
          <div class="row align-items-center">
            <div class="col-md-1 text-center">
              <img src="img/gos.png" alt="Городской ломбард" class="w-100">
            </div>
            <div class="col-md-2 text-center">
              <a href="https://goslombard.ru" target="_blank" class="rating__site"><span class="rating__add gray">Сайт:&nbsp;</span>goslombard.ru</a>
            </div>
            <div class="col-md-3 text-center">
              <p class="px-1"><span class="rating__add gray">Виды залога:&nbsp;</span>Ювелирные украшения, часы, технику, одежду и аксессуары</p>
            </div>
            <div class="col-md-2 text-center">
              <p class="rating__network"><span class="rating__add gray">Сетевой ломбард:&nbsp;</span>Нет</p>
            </div>
            <div class="col-md-2 text-center ">
              <b>3,8 из 5</b><br>
              <p class="gray rating__count-reviews">(10 отзывов)</p>
              <button class="btn btn-link rating__btn-reviews" type="button" data-toggle="collapse" data-target="#collapse2" aria-expanded="false" aria-controls="collapseOne">Читать отзывы</button>
            </div>
            <div class="col-md-2">
              <a href="goslombard.html" class="second-btn rating__btn">Подробнее</a>
            </div>
          </div>
          <div id="collapse2" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
            <div class="card-body">
              <div class="col-12">
                <div class="owl-carousel owl-theme rating__reviews_owl-carousel">
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Артур Р.</h3>
                      <p class="gray fz14">3 марта 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Всё на уровне</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Мария З.</h3>
                      <p class="gray fz14">3 марта 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Отличное место</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Родина- мать твоя</h3>
                      <p class="gray fz14">10 февраля 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Может сам ломбард и хороший, не успели оценить качество ювелирных украшений. Нужно было срочно купить золотой браслет, приехали в данный ломбард в 19:40, но нам сказали, что уже поздно, хотя он работает до 20:00. Пытались уговорить показать нам браслеты, но было сказано, завтра приходите. Очень жаль, хозяин ломбард упустил клиента и соответственно прибыль, так как покупка должна была быть не менее 15000 руб.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header" id="headingOne">
          <div class="row align-items-center">
            <div class="col-md-1 text-center">
              <img src="img/master.png" alt="Мастер-Ломбард" class="w-100">
            </div>
            <div class="col-md-2 text-center">
              <a href="https://lombard-master.ru" target="_blank" class="rating__site"><span class="rating__add gray">Сайт:&nbsp;</span>lombard-master.ru</a>
            </div>
            <div class="col-md-3 text-center">
              <p class="px-1"><span class="rating__add gray">Виды залога:&nbsp;</span>Автомобили, ювелирные украшения, часы, технику, недвижимость, спецтехнику, одежду и аксессуары, яхты</p>
            </div>
            <div class="col-md-2 text-center">
              <p class="rating__network"><span class="rating__add gray">Сетевой ломбард:&nbsp;</span>Нет</p>
            </div>
            <div class="col-md-2 text-center ">
              <b>4,0 из 5</b><br>
              <p class="gray rating__count-reviews">(3 отзыва)</p>
              <button class="btn btn-link rating__btn-reviews" type="button" data-toggle="collapse" data-target="#collapse3" aria-expanded="false" aria-controls="collapseOne">Читать отзывы</button>
            </div>
            <div class="col-md-2">
              <a href="master.html" class="second-btn rating__btn">Подробнее</a>
            </div>
          </div>
          <div id="collapse3" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
            <div class="card-body">
              <div class="col-12">
                <div class="owl-carousel owl-theme rating__reviews_owl-carousel">
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Сол и’Пси с.т.</h3>
                      <p class="gray fz14">17 февраля 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Ну это такая вещь.... Может кому и пригодится.</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Дарья Г.</h3>
                      <p class="gray fz14">3 ноября 2019</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">На продажу много всего интересного по хорошим ценам.</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Chi4va@mail Чичёва</h3>
                      <p class="gray fz14">19 августа 2018</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Хороший ломбард.Приятные оценщики. Много выбора шуб, техники, ювелирных изделий.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header" id="headingOne">
          <div class="row align-items-center">
            <div class="col-md-1 text-center">
              <img src="img/9999.png" alt="ЛОМБАРД 9999" class="w-100">
            </div>
            <div class="col-md-2 text-center">
              <a href="https://9999lombard.ru" target="_blank" class="rating__site"><span class="rating__add gray">Сайт:&nbsp;</span>9999lombard.ru</a>
            </div>
            <div class="col-md-3 text-center">
              <p class="px-1"><span class="rating__add gray">Виды залога:&nbsp;</span>Ювелирные украшения</p>
            </div>
            <div class="col-md-2 text-center">
              <p class="rating__network"><span class="rating__add gray">Сетевой ломбард:&nbsp;</span>Нет</p>
            </div>
            <div class="col-md-2 text-center ">
              <b>5,0 из 5</b><br>
              <p class="gray rating__count-reviews">(2 отзыва)</p>
              <button class="btn btn-link rating__btn-reviews" type="button" data-toggle="collapse" data-target="#collapse4" aria-expanded="false" aria-controls="collapseOne">Читать отзывы</button>
            </div>
            <div class="col-md-2">
              <a href="9999lombard.html" class="second-btn rating__btn">Подробнее</a>
            </div>
          </div>
          <div id="collapse4" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
            <div class="card-body">
              <div class="col-12">
                <div class="owl-carousel owl-theme rating__reviews_owl-carousel">
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Виктория Басова</h3>
                      <p class="gray fz14">24 октября 2019</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Отличное обслуживание, низкий процент, доброжелательный персонал. Спасибо, обращалась уже несколько раз, всё устраивает.</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Владимир Сиухин</h3>
                      <p class="gray fz14">18 октября 2019</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Хорошее обслуживание! Низкий %</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header" id="headingOne">
          <div class="row align-items-center">
            <div class="col-md-1 text-center">
              <img src="img/ident.png" alt="АВТО ЛОМБАРД ИДЕНТ" class="w-100">
            </div>
            <div class="col-md-2 text-center">
              <a href="http://avtoident.ru" target="_blank" class="rating__site"><span class="rating__add gray">Сайт:&nbsp;</span>avtoident.ru</a>
            </div>
            <div class="col-md-3 text-center">
              <p class="px-1"><span class="rating__add gray">Виды залога:&nbsp;</span>Автомобили, ювелирные украшения</p>
            </div>
            <div class="col-md-2 text-center">
              <p class="rating__network"><span class="rating__add gray">Сетевой ломбард:&nbsp;</span>Нет</p>
            </div>
            <div class="col-md-2 text-center ">
              <b>5,0 из 5</b><br>
              <p class="gray rating__count-reviews">(3 отзыва)</p>
              <button class="btn btn-link rating__btn-reviews" type="button" data-toggle="collapse" data-target="#collapse5" aria-expanded="false" aria-controls="collapseOne">Читать отзывы</button>
            </div>
            <div class="col-md-2">
              <a href="ident.html" class="second-btn rating__btn">Подробнее</a>
            </div>
          </div>
          <div id="collapse5" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
            <div class="card-body">
              <div class="col-12">
                <div class="owl-carousel owl-theme rating__reviews_owl-carousel">
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Аркадий Д.</h3>
                      <p class="gray fz14">10 июля 2019</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Был в этом ломбарде в 2016 году. Практически ничего не поменялось. 30 минут и уехал с деньгами. Давно работают ребята. Немного уменьшили сумму из-за вмятины на двери</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Антон А.</h3>
                      <p class="gray fz14">10 июля 2019</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Xорошие ставки. работают честно, как сказали так и сделали. молодцы.</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Сергей Самсонов</h3>
                      <p class="gray fz14">17 марта 2017</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Спасибо за сотрудничество!</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header" id="headingOne">
          <div class="row align-items-center">
            <div class="col-md-1 text-center">
              <img src="img/capit.jpg" alt="ЛОМБАРД СТОЛИЧНЫЙ" class="w-100">
            </div>
            <div class="col-md-2 text-center">
              <a href="http://lombardst.ru" target="_blank" class="rating__site"><span class="rating__add gray">Сайт:&nbsp;</span>lombardst.ru</a>
            </div>
            <div class="col-md-3 text-center">
              <p class="px-1"><span class="rating__add gray">Виды залога:&nbsp;</span>Ювелирные украшения</p>
            </div>
            <div class="col-md-2 text-center">
              <p class="rating__network"><span class="rating__add gray">Сетевой ломбард:&nbsp;</span>Нет</p>
            </div>
            <div class="col-md-2 text-center ">
              <b>4,6 из 5</b><br>
              <p class="gray rating__count-reviews">(10 отзывов)</p>
              <button class="btn btn-link rating__btn-reviews" type="button" data-toggle="collapse" data-target="#collapse6" aria-expanded="false" aria-controls="collapseOne">Читать отзывы</button>
            </div>
            <div class="col-md-2">
              <a href="lombardst.html" class="second-btn rating__btn">Подробнее</a>
            </div>
          </div>
          <div id="collapse6" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
            <div class="card-body">
              <div class="col-12">
                <div class="owl-carousel owl-theme rating__reviews_owl-carousel">
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Ирина</h3>
                      <p class="gray fz14">17 марта 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Ужасный ломбард,оценщик даже не может посчитать процент. А оценка изделия получается по цене меньше лома.</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Алина Закора</h3>
                      <p class="gray fz14">17 марта 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Обращалась в этот ломбард пару раз. Условия хорошие, брала тут деньги под залог золота. Будет необходимость - буду обращаться снова</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Кирилл Разумков</h3>
                      <p class="gray fz14">17 марта 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Хороший ломбард, часто сюда прихожу и беру деньги под залог техники или драгоценностей. Условия выгодные, я доволен.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header" id="headingOne">
          <div class="row align-items-center">
            <div class="col-md-1 text-center">
              <img src="img/express.png" alt="ЛОМБАРД ЗОЛОТАЯ ВЬЮГА" class="w-100">
            </div>
            <div class="col-md-2 text-center">
              <a href="http://gold500.ru" target="_blank" class="rating__site"><span class="rating__add gray">Сайт:&nbsp;</span>gold500.ru</a>
            </div>
            <div class="col-md-3 text-center">
              <p class="px-1"><span class="rating__add gray">Виды залога:&nbsp;</span>Ювелирные украшения</p>
            </div>
            <div class="col-md-2 text-center">
              <p class="rating__network"><span class="rating__add gray">Сетевой ломбард:&nbsp;</span>Нет</p>
            </div>
            <div class="col-md-2 text-center ">
              <b>4,3 из 5</b><br>
              <p class="gray rating__count-reviews">(9 отзывов)</p>
              <button class="btn btn-link rating__btn-reviews" type="button" data-toggle="collapse" data-target="#collapse7" aria-expanded="false" aria-controls="collapseOne">Читать отзывы</button>
            </div>
            <div class="col-md-2">
              <a href="gold500.html" class="second-btn rating__btn">Подробнее</a>
            </div>
          </div>
          <div id="collapse7" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
            <div class="card-body">
              <div class="col-12">
                <div class="owl-carousel owl-theme rating__reviews_owl-carousel">
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Юлия В.</h3>
                      <p class="gray fz14">16 февраля 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Быстро и цены приемлемые, сдавала, курс был второй по высоте по Москве.</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Тимур Щепетнов</h3>
                      <p class="gray fz14">12 февраля 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Месторасположение очень удобное.</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Юленька</h3>
                      <p class="gray fz14">1 февраля 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Хороший ломбард. Приятные сотрудники . Всегда подскажут и посоветуют.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header" id="headingOne">
          <div class="row align-items-center">
            <div class="col-md-1 text-center">
              <img src="img/cash.png" alt="ЛОМБАРД ЗОЛОТАЯ ВЬЮГА" class="w-100">
            </div>
            <div class="col-md-2 text-center">
              <a href="http://cash4gold.ru" target="_blank" class="rating__site"><span class="rating__add gray">Сайт:&nbsp;</span>cash4gold.ru</a>
            </div>
            <div class="col-md-3 text-center">
              <p class="px-1"><span class="rating__add gray">Виды залога:&nbsp;</span>Ювелирные украшения</p>
            </div>
            <div class="col-md-2 text-center">
              <p class="rating__network"><span class="rating__add gray">Сетевой ломбард:&nbsp;</span>Нет</p>
            </div>
            <div class="col-md-2 text-center ">
              <b>4,0 из 5</b><br>
              <p class="gray rating__count-reviews">(10 отзывов)</p>
              <button class="btn btn-link rating__btn-reviews" type="button" data-toggle="collapse" data-target="#collapse8" aria-expanded="false" aria-controls="collapseOne">Читать отзывы</button>
            </div>
            <div class="col-md-2">
              <a href="cash4gold.html" class="second-btn rating__btn">Подробнее</a>
            </div>
          </div>
          <div id="collapse8" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
            <div class="card-body">
              <div class="col-12">
                <div class="owl-carousel owl-theme rating__reviews_owl-carousel">
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Avtoyarik</h3>
                      <p class="gray fz14">27 февраля 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Квалификация сотрудников на низком уровне.</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>sl112k96</h3>
                      <p class="gray fz14">23 февраля 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Вежливые тавароведы.</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Владимир И.</h3>
                      <p class="gray fz14">16 февраля 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Не давнно был</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header" id="headingOne">
          <div class="row align-items-center">
            <div class="col-md-1 text-center">
              <img src="img/38.svg" alt="ЛОМБАРД № 38" class="w-100">
            </div>
            <div class="col-md-2 text-center">
              <a href="http://lombard38.ru" target="_blank" class="rating__site"><span class="rating__add gray">Сайт:&nbsp;</span>lombard38.ru</a>
            </div>
            <div class="col-md-3 text-center">
              <p class="px-1"><span class="rating__add gray">Виды залога:&nbsp;</span>Ювелирные украшения</p>
            </div>
            <div class="col-md-2 text-center">
              <p class="rating__network"><span class="rating__add gray">Сетевой ломбард:&nbsp;</span>Нет</p>
            </div>
            <div class="col-md-2 text-center ">
              <b>4,2 из 5</b><br>
              <p class="gray rating__count-reviews">(10 отзывов)</p>
              <button class="btn btn-link rating__btn-reviews" type="button" data-toggle="collapse" data-target="#collapse9" aria-expanded="false" aria-controls="collapseOne">Читать отзывы</button>
            </div>
            <div class="col-md-2">
              <a href="lombard38.html" class="second-btn rating__btn">Подробнее</a>
            </div>
          </div>
          <div id="collapse9" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
            <div class="card-body">
              <div class="col-12">
                <div class="owl-carousel owl-theme rating__reviews_owl-carousel">
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Евгения Евгения</h3>
                      <p class="gray fz14">17 марта 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">На протяжении 4-5 лет пользуюсь услугами этого ломбарда, изделия оценивают максимально, всегда доброжелательны. Была ситуация, когда я забыла про дату выкупа, а в этот момент уехала из Москвы, позвонила в ломбард, объяснила ситуацию и мне пошли навстречу, не выставили изделие на продажу, по возвращению забрала украшение. Огромная вам благодарность за понимание и лояльное отношение к клиентам.</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Милена Азатян</h3>
                      <p class="gray fz14">17 марта 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Очень хорошая команда и очень доступные и красивые вещи у вас ))) благодарю вам за мои покупки что я приобрела у вас 🎉 ребята вы супер рекомендую всем !!!</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>ВSTARINA SAN</h3>
                      <p class="gray fz14">17 марта 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Обращался в Автоломбард уже третий раз. Каждый раз проходило все четко,без обмана. Последний залог затянулся почти на год. Сотрудники всегда звонили напоминали о платежах. За весь срок было несколько просрочек, отнеслись к ситуации с пониманием. Машину вернули быстро и без проблем. Если сложились обстоятельства,что срочно нужны деньги, эту компанию точно рекомендую.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header" id="headingOne">
          <div class="row align-items-center">
            <div class="col-md-1 text-center">
              <img src="img/cilesta.png" alt="ЛОМБАРД ЦИЛЕСТА" class="w-100">
            </div>
            <div class="col-md-2 text-center">
              <a href="http://cilesta.ru" target="_blank" class="rating__site"><span class="rating__add gray">Сайт:&nbsp;</span>cilesta.ru</a>
            </div>
            <div class="col-md-3 text-center">
              <p class="px-1"><span class="rating__add gray">Виды залога:&nbsp;</span>Ювелирные украшения, одеждa и аксессуары</p>
            </div>
            <div class="col-md-2 text-center">
              <p class="rating__network"><span class="rating__add gray">Сетевой ломбард:&nbsp;</span>Нет</p>
            </div>
            <div class="col-md-2 text-center ">
              <b>4,1 из 5</b><br>
              <p class="gray rating__count-reviews">(7 отзывов)</p>
              <button class="btn btn-link rating__btn-reviews" type="button" data-toggle="collapse" data-target="#collapse10" aria-expanded="false" aria-controls="collapseOne">Читать отзывы</button>
            </div>
            <div class="col-md-2">
              <a href="cilesta.html" class="second-btn rating__btn">Подробнее</a>
            </div>
          </div>
          <div id="collapse10" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
            <div class="card-body">
              <div class="col-12">
                <div class="owl-carousel owl-theme rating__reviews_owl-carousel">
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Сергей С.</h3>
                      <p class="gray fz14">3 марта 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Отличный персонал ,маленькие проценты</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>RX&amp;ASX</h3>
                      <p class="gray fz14">28 января 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">ООоооо,много чего есть!!Выбор приличный.Есть шубы в том числе.</p>
                  </div>
                  <div class="item">
                    <div class="d-flex justify-content-between">
                      <h3>Charles Perrault</h3>
                      <p class="gray fz14">17 января 2020</p>
                    </div>
                    <div class="reviews__item_line rating-reviews__item_line"></div>
                    <p class="mt-4 pt-3">Хороший ломбард. Рекомендую. Ценник намного выше тех что оценивает Ломбард 24.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>
<section class="request" id="request">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 col-xl-7">
        <div class="request__offer">
          <h1>Мы заплатим за вас проценты</h1>
          <p>Обратитесь сегодня и получите кредит<br>на один месяц абсолютно бесплатно</p>
        </div>
      </div>
      <div class="col-lg-6 col-xl-5 text-center">
        <form action="send.php" method="post" class="requset__form text-center">
          <h3>Не охота разбираться</h3>
          <p class="mt-1">Позвоните или напишите мне</p>
          <input type="text" name="request-name" placeholder="Ваше имя" required>
          <input type="tel" name="request-tel" placeholder="Телефон" required>
          <input type="email" name="request-email" placeholder="Email">
          <button type="submit" class="main-btn">Оставить заявку</button>
        </form>
      </div>
    </div>
  </div>
</section>
<section class="mass-media" id="mass-media">
  <div class="container">
    <div class="row">
      <div class="col-12 text-center">
        <h2>Что пишут о нас в СМИ</h2>
      </div>
    </div>
    <div class="row mt-5 pt-1">
      <div class="col-lg-3 col-md-6 mt-3">
        <a href="https://www.kommersant.ru/doc/4227879" class="mass-media__item d-flex align-items-center justify-content-center" target="_blank">
          <img src="img/m1.png" alt="КомерсантЪ">
        </a>
      </div>
      <div class="col-lg-3 col-md-6 mt-3">
        <a href="https://www.kolesa.ru/news/zalog-v-bezopasnosti-v-rossii-zarabotal-pervyy-agregator-avtolombardov" class="mass-media__item d-flex align-items-center justify-content-center" target="_blank">
          <img src="img/m2.png" alt="koleca.ru">
        </a>
      </div>
      <div class="col-lg-3 col-md-6 mt-3">
        <a href="https://www.banki.ru/news/lenta/?id=10915650" class="mass-media__item d-flex align-items-center justify-content-center" target="_blank">
          <img src="img/m3.png" alt="banki.ru">
        </a>
      </div>
      <div class="col-lg-3 col-md-6 mt-3">
        <a href="https://bankir.ru/novosti/20200124/agregator-dla-avtolombardov-planiruet-ohvatit-ves-lombardnyj-rynok-10171444/" class="mass-media__item d-flex align-items-center justify-content-center" target="_blank">
          <img src="img/m4.png" alt="bankir.ru">
        </a>
      </div>
    </div>
  </div>
</section>
<section class="reviews" id="reviews">
  <div class="container">
    <div class="row">
      <div class="col-12 text-center">
        <h2>Отзывы клиентов</h2>
      </div>
      <div class="col-12">
        <div class="owl-carousel owl-theme reviews__owl-carousel">
          <div class="item">
            <div class="d-flex justify-content-between">
              <h3>Александр Невский</h3>
              <p class="gray fz14">15 февраля 2020</p>
            </div>
            <div class="reviews__item_line"></div>
            <p class="mt-4 pt-3">Обратился в НМlot осенью 2018 г. Брал займ под ПТС. Для меня - это удобный вариант найти нужную мне сумму за короткий срок. Обычно различные кредитные организации предлагают сумму вдвое меньше рыночной стоимости предмета залога. А через HMlot я смог быстро найти сумму займа выше подавляющего большинства подобных предложений на рынке кредитования. В итоге мне предложили адекватную сумму займа. Это еще один плюс компании, что она работает с широким кругом партнеров и есть возможность подобрать действительно подходящее предложения конкретно под меня. Из минусы, что все-таки нужно платить проценты за пользование займом, но что поделаешь таковы реалии…. А так, проблем особых не возникло.</p>
            <div class="reviews__info d-flex justify-content-between mt-5">
              <div class="reviews__img" style="background: url(img/reviews.jpg) no-repeat center center / cover;"></div>  
              <div class="fz14"> 
                <p><span class="gray">Марка:&nbsp;</span>Toyota</p>
                <p><span class="gray">Модель:&nbsp;</span>Camry</p>
                <p><span class="gray">Год выпуска:&nbsp;</span>2009</p>
                <p><span class="gray">Пробег:&nbsp;</span>150 000 км</p>
                <p><span class="gray">Цвет:&nbsp;</span>Белый</p>
                <p><span class="gray">Двигатель:&nbsp;</span>2.4 л / 167 л.с. / Бензин</p>
                <p><span class="gray">Коробка:&nbsp;</span>АКПП</p>
                <p><span class="gray">VIN:&nbsp;</span>4T1BF3EK*AU****04</p>
                <p><span class="gray">Срок займа:&nbsp;</span>3 мес</p>
              </div>
              <div class="fz14"> 
                <p><span class="gray">Количество ставок:&nbsp;</span>93</p>
                <p><span class="gray">Просмотров:&nbsp;</span>51</p>
                <p><span class="gray">Лучшая сумма:&nbsp;</span>480 000 под 6% в мес</p>
                <p><span class="gray">Лучшая ставка:&nbsp;</span>413 000 под 4% в мес</p>
                <p><span class="gray">Ближайшее предложение:&nbsp;</span>м. Кузьминки, 385 000<br>под 5% в мес</p>
              </div>           
            </div>
          </div>
          <div class="item">
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="base">
  <div class="container">
    <div class="row">
      <div class="col-lg-3 col-md-4 col-sm-6 col-12 mt-5">
        <h3 class="mb-3">Автомобили</h3>
        <a href="/article1-1.html">Подводные камни при работе с нечестными автоломбардами</a>
        <a href="/article1-2.html">Что такое заем под залог ПТС</a>
        <a href="/article1-3.html">Как работают автоломбарды</a>
      </div>
      <div class="col-lg-3 col-md-4 col-sm-6 col-12 mt-5">
        <h3 class="mb-3">Ювелирные изделия</h3>
        <a href="/article2-1.html">Как проводится оценка ювелирного украшения с камнем и без</a>
        <a href="/article2-2.html"> Какие документы нужны для оформления займа в ювелирном ломбарде?</a>
      </div>
      <div class="col-lg-3 col-md-4 col-sm-6 col-12 mt-5">
        <h3 class="mb-3">Часы</h3>
        <a href="/article3-1.html">Как происходит оценка часов</a>
        <a href="/article3-2.html">Как проверяется подлинность брендовых часов в ломбарде</a>
        <a href="/article3-3.html">Документы для оформления займа в ломбарде часов</a>
      </div>
      <div class="col-lg-3 col-md-4 col-sm-6 col-12 mt-5">
        <h3 class="mb-3">Техника</h3>
        <a href="/article4-1.html">Что принимается в залог из бытовой техники?</a>
        <a href="/article4-2.html">Какие телефоны принимают ломбарды</a>
        <a href="/article4-3.html">Как можно сдать телефон в ломбард</a>
      </div>
      <div class="col-lg-3 col-md-4 col-sm-6 col-12 mt-5">
        <h3 class="mb-3">Недвижимость</h3>
        <a href="/article5-1.html">Если заемщик уклоняется от выплаты кредита</a>
        <a href="/article5-2.html">Процесс получения займа под залог недвижимости в ломбарде</a>
      </div>
      <div class="col-lg-3 col-md-4 col-sm-6 col-12 mt-5">
        <h3 class="mb-3">Спецтехника</h3>
        <a href="/article6-1.html">Особенности получения займа под залог спецтехники</a>
      </div>
      <div class="col-lg-3 col-md-4 col-sm-6 col-12 mt-5">
        <h3 class="mb-3">Одежда и аксессуары</h3>
        <a href="/article7-1.html">Как происходит процесс сдачи в ломбард одежды и аксессуаров?</a>
        <a href="/article7-2.html">Что влияет на оценку шубы ломбардом</a>
      </div>
      <div class="col-lg-3 col-md-4 col-sm-6 col-12 mt-5">
        <h3 class="mb-3">Яхты</h3>
        <a href="/article8-1.html">Требования к заемщику и водному транспорту</a>
        <a href="/article8-2.html">Как и где получить кредит под залог водного транспорта?</a>
      </div>
    </div>
  </div>
</section>
<footer class="footer">
  <div class="container">
    <div class="row">
      <div class="col-xl-7">
        <ul class="footer__menu d-flex">
          <li><a href="#history" class="go">История</a></li>
          <li><a href="#warranty" class="go">Гарантии</a></li>
          <li><a href="#rating" class="go">Рейтинг ломбардов</a></li>
          <li><a href="#mass-media" class="go">СМИ о нас</a></li>
          <li><a href="#reviews" class="go">Отзывы клиентов</a></li>
        </ul>
      </div>
      <div class=" col-xl-2">
        <p class="copyright">© 2020 Sravni lombard</p>
      </div>
      <div class="col-xl-3">
        <a href="tel:+8 (800) 333-89-04" class="header__tel footer__tel">+8 (800) 333-89-04</a>
      </div>
      <div class="col-12">
        <p class="mt-4 footer__text">Сайт sravnilombard не осуществляет финансовую деятельностьпо выдаче кредитов и займов, не является сайтом банка или какой-либо финансовой оргнизации, не оказывает услуг по выдаче займови кредитов. Сайт информирует о существующих кредитных продуках МФК и банковф РФ для сравненияи подбора наилучшего варианта кредитования. Все организации, представленные на сайте имеют лицензию ЦБ РФ на финансовую деятельость. Все условия кредитования носят справочный характери взяты из открытых источников, реальные условия уточняйте при обращении к кредитору</p>
      </div>
    </div>
  </div>
</footer>

  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  <script src="owlcarousel/owl.carousel.min.js"></script>
  <script src="js/main.js"></script>
</body>
</html>





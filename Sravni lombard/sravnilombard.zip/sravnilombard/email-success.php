<!doctype html>
<html lang="ru">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>ReBottle</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css"> 
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700,900&display=swap&subset=cyrillic" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="stylesheet" href="css/animate.css">
  <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="stylesheet" href="css/main.css">
</head>
<body>

<div class="container">
	<div class="row">
		<div class="col-12 text-center">
			<div class="send-success">
				<i class="fas fa-check-circle"></i>
				<h3 class="mt-5">Спасибо за заявку!</h3>
				<p class="px-4 mt-4">Уже скоро Вам на почту придут советы</p>
			</div>
		</div>
	</div>
</div>

<script language="JavaScript" type="text/javascript">
function changeurl(){eval(self.location="index.php");}
window.setTimeout("changeurl();",5000);
</script>


</body>
</html>